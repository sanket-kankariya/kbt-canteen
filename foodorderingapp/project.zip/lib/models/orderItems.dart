import 'package:flutter/cupertino.dart';

class OrderItems{
  String number;
  String itemName;
  String weight;
  int amount;
  OrderItems({@required this.number,@required this.itemName,@required this.weight,@required this.amount});
}