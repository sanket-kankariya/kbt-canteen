import 'package:foodorderingapp/models/user.dart';

AppCurrentUser appCurrentUser;
