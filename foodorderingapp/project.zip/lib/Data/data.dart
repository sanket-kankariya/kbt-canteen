import 'package:foodorderingapp/models/orderItems.dart';
import 'package:foodorderingapp/screens/orderdetails.dart';

// List<String> nearbyLocations = [
//   'Adgaon',
//   'Anusuya Nagar',
//   'Ashok Sthamb',
//   'Bytco Point',
//   'Canada Corner',
//   'College Road',
//   'Dwarka',
//   'Fulenagar',
//   'Gangapur Road',
//   'Gole Colony',
//   'Govind Nagar',
//   'Indira Nagar',
//   'Jail Road',
//   'Mahatma Nagar',
//   'MG Road',
//   'Mumbai Agra Road',
//   'Mumbai Naka',
//   'Nashik Main Road',
//   'Nashik Road',
//   'Old Agra Road',
//   'Panchvati',
//   'Nashik Pune Road',
//   'Raviwar Peth',
//   'Saibaba Nagar',
//   'CDO-MERI Colony',
//   'Sane Guruji Nagar',
//   'Satpur',
//   'Shalimar',
//   'Sharanpur',
//   'Sharanpur Road',
//   'Shivaji Nagar',
//   'Shivaji Road',
//   'Sawarkar Nagar',
//   'Shramik Nagar',
//   'Tidke Nagar',
//   'Tilak Road',
//   'Pathardi Gaon',
//   'Parab Nagar',
//   'Trimbak Road',
//   'Trimurti Chowk',
//   'Vakil Wadi',
//   'Vrindavan Colony',
//   'Koknipura'
// ];

List<OrderItems> orderedItem = [];


