class AppCurrentUser {
  String uid;
  String displayName;
  String email;
  String photoUrl;
  String location;

  AppCurrentUser({
    this.uid,
    this.displayName,
    this.email,
    this.photoUrl,
    this.location,
  });
}
